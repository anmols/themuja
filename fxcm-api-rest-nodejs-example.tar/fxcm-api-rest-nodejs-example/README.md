# fxcm-api-rest-nodejs-example
FXCM RESTful API client example for nodejs.

Requrements:
1. Node.js version 4 or greater
2. Socket.IO version 1.7.3 (you can use 'npm install')

To run this example:

1. Rename or copy config.sample.js into config.js
2. Change token, host, port and protocol in config.js
3. Start the client with: node main.js
4. Use commands from commands.txt
