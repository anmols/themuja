var config = {};

config.token = "PASTE_YOUR_TOKEN_HERE"; // get this from http://tradingstation.fxcm.com/
config.trading_api_host = 'api-demo.fxcm.com';
config.trading_api_port = 443;
config.trading_api_proto = 'https'; // http or https

module.exports = config;