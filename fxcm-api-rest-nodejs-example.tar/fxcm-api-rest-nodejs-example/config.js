var config = {};

//config.token = "194ea7b307339c15e64fdaddee023c60fdee2c57"; // get this from http://tradingstation.fxcm.com/
config.token = "a0c448045fd798a838fd94f6bff0b7b9f67e6cdf"; // get this from http://tradingstation.fxcm.com/
config.trading_api_host = 'api-demo.fxcm.com';
config.trading_api_port = 443;
config.trading_api_proto = 'https'; // http or https

module.exports = config;